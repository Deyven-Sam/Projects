// import logo from './logo.svg';
import './App.css';
import {Navbar, Container, Nav, NavDropdown, Carousel} from 'react-bootstrap'
import Figure from 'react-bootstrap/Figure'
import 'bootstrap/dist/css/bootstrap.min.css';
function App() {
  return (
    <div className="App">


    <Navbar bg="light" expand="lg" >
      <Container>
        <Navbar.Brand href="#home">Movie-Maker</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link href="#home">Home</Nav.Link>
            <Nav.Link href="#link">Contact</Nav.Link>
            <NavDropdown title="Articles" id="basic-nav-dropdown">
              <NavDropdown.Item href="#action/3.1">Strawberry</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">Banana</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Apple</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4">Devil fruit</NavDropdown.Item>
            </NavDropdown>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>



    <Carousel>
          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://upload.wikimedia.org/wikipedia/en/c/c1/You_%28TV_series%29_intertitle.png"
              alt="First slide"
            />
            <Carousel.Caption>
              <h3>MURDER ATTEMPT</h3>
              <p>CHAPTER 1</p>
            </Carousel.Caption>
          </Carousel.Item>


          <Carousel.Item>
                  <img
                    className="d-block w-100"
                    src="https://product-image.juniqe-production.juniqe.com/media/catalog/product/seo-cache/x800/643/24/643-24-101L/YEAH-petiteCAPS-Poster.jpg"
                    alt="Second slide"/>
                  <Carousel.Caption>
                  <div id="second">
                    <h5>WHAT !!!</h5>
                    <p>CHAPTER 2</p>
                    </div>
                  </Carousel.Caption>
                </Carousel.Item>


          <Carousel.Item>
            <img
              className="d-block w-100"
              src="https://upload.wikimedia.org/wikipedia/en/c/c1/You_%28TV_series%29_intertitle.png"
              alt="Third slide"
            />
            <Carousel.Caption>
              <h3>BUTCHERED</h3>
              <p>CHAPTER 3</p>
            </Carousel.Caption>
          </Carousel.Item>
        </Carousel>



<Figure>
      <Figure.Image

        alt="figure"
        src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcReELEQ-I2_JPFMYvdnt-xh0_EAUHSFF_QBYg&usqp=CAU"
      />
      <Figure.Caption>
        JUNGLE CRUISE
      </Figure.Caption>
    </Figure>

    <Figure>
          <Figure.Image

            alt="figure"
            src="https://i.pinimg.com/236x/ae/19/70/ae197019f8e63a6210993a4aea5a23d6.jpg"
          />
          <Figure.Caption>
            BEAUTY AND THE BEAST
          </Figure.Caption>
        </Figure>

        <Figure>
              <Figure.Image

                alt="figure"
                src="https://www.indiewire.com/wp-content/uploads/2019/12/nightingale-1.jpeg?w=675"
              />
              <Figure.Caption>
                The NIGHTINGALE
              </Figure.Caption>
            </Figure>

            <Figure>
                  <Figure.Image

                    alt="figure"
                    src="https://i.pinimg.com/236x/d8/3b/53/d83b5353d21d94c0ab7a3427f20d6a0a.jpg"
                  />
                  <Figure.Caption>
                    LONDON HAS FALLEN
                  </Figure.Caption>
                </Figure>






    </div>


  );
}

export default App;
